///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	stbi_set_flip_vertically_on_load(true);

	unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);

		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;
	return false;
}

void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return textureID;
}

int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return textureSlot;
}

bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return false;
	}

	int index = 0;
	bool bFound = false;

	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;

			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return bFound;
}

void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	scale = glm::scale(scaleXYZ);
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = FindMaterial(materialTag, material);

		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 * PrepareScene()
 ***********************************************************/

 /***********************************************************
  * DefineObjectMaterials()
  ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.45f, 0.28f, 0.10f);
	woodMaterial.ambientStrength = 0.8f;
	woodMaterial.diffuseColor = glm::vec3(0.65f, 0.45f, 0.20f);
	woodMaterial.specularColor = glm::vec3(0.25f, 0.25f, 0.25f);
	woodMaterial.shininess = 16.0f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL leatherMaterial;
	leatherMaterial.ambientColor = glm::vec3(0.35f, 0.35f, 0.35f);
	leatherMaterial.ambientStrength = 0.9f;
	leatherMaterial.diffuseColor = glm::vec3(0.30f, 0.30f, 0.30f);
	leatherMaterial.specularColor = glm::vec3(0.70f, 0.70f, 0.70f);
	leatherMaterial.shininess = 96.0f;
	leatherMaterial.tag = "leather";
	m_objectMaterials.push_back(leatherMaterial);

	OBJECT_MATERIAL carbonMaterial;
	carbonMaterial.ambientColor = glm::vec3(0.40f, 0.40f, 0.40f);
	carbonMaterial.ambientStrength = 0.9f;
	carbonMaterial.diffuseColor = glm::vec3(0.35f, 0.35f, 0.35f);
	carbonMaterial.specularColor = glm::vec3(0.90f, 0.90f, 0.90f);
	carbonMaterial.shininess = 128.0f;
	carbonMaterial.tag = "carbon";
	m_objectMaterials.push_back(carbonMaterial);
}

/***********************************************************
 * SetupSceneLights()
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// White overhead light
	m_pShaderManager->setVec3Value(
		"pointLights[0].position",
		0.0f, 1.75f, 1.0f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].ambient",
		0.35f, 0.35f, 0.35f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].diffuse",
		1.2f, 1.2f, 1.2f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].specular",
		1.4f, 1.4f, 1.4f);

	m_pShaderManager->setBoolValue(
		"pointLights[0].bActive",
		true);


	// Red accent light
	m_pShaderManager->setVec3Value(
		"pointLights[1].position",
		2.0f, 2.5f, 2.0f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].ambient",
		0.10f, 0.02f, 0.02f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].diffuse",
		1.0f, 0.20f, 0.20f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].specular",
		1.0f, 0.30f, 0.30f);

	m_pShaderManager->setBoolValue(
		"pointLights[1].bActive",
		true);

	m_pShaderManager->setBoolValue(
		"bUseLighting",
		true);
}


void SceneManager::PrepareScene()
{
	// Load every basic mesh needed for the headset model.

	//Adding texture

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadBoxMesh();
	
	CreateGLTexture("textures/wood.jpg", "wood");
	CreateGLTexture("textures/carbon.jpg", "carbon");
	CreateGLTexture("textures/leather.png", "leather");

	DefineObjectMaterials();
	SetupSceneLights();
	
	BindGLTextures();
}

/***********************************************************
 * RenderScene()
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// ---------- DESK / MOUSEPAD PLANE ----------
	//DESK Wood

	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	SetTextureUVScale(6.0f, 6.0f);
	scaleXYZ = glm::vec3(8.0f, 1.0f, 5.0f);
	positionXYZ = glm::vec3(0.0f, -0.65f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawPlaneMesh();

	//EAR CUPS Leather
	// ---------- LEFT EAR CUP ----------
	
	SetShaderTexture("leather");
	SetShaderMaterial("leather");
	SetTextureUVScale(1.0f, 1.0f);
	scaleXYZ = glm::vec3(0.75f, 0.35f, 0.75f);
	positionXYZ = glm::vec3(-1.25f, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// ---------- RIGHT EAR CUP ----------
	SetShaderTexture("leather");
	SetShaderMaterial("leather");
	SetTextureUVScale(1.0f, 1.0f);
	scaleXYZ = glm::vec3(0.75f, 0.35f, 0.75f);
	positionXYZ = glm::vec3(1.25f, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// ---------- LEFT EAR CUSHION ----------
	SetShaderTexture("leather");
	SetShaderMaterial("leather");
	SetTextureUVScale(1.0f, 1.0f);
	scaleXYZ = glm::vec3(0.82f, 0.82f, 0.20f);
	positionXYZ = glm::vec3(-1.25f, 0.0f, -0.08f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawTorusMesh();

	// ---------- RIGHT EAR CUSHION ----------
	SetShaderTexture("leather");
	SetShaderMaterial("leather");
	SetTextureUVScale(1.0f, 1.0f);
	scaleXYZ = glm::vec3(0.82f, 0.82f, 0.20f);
	positionXYZ = glm::vec3(1.25f, 0.0f, -0.08f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawTorusMesh();


	//  HEADBAND Carbon
	// ---------- OUTER HEADBAND ----------
	SetShaderTexture("carbon");
	SetShaderMaterial("carbon");
	SetTextureUVScale(1.0f, 1.0f);
	scaleXYZ = glm::vec3(1.75f, 1.75f, 0.16f);
	positionXYZ = glm::vec3(0.0f, 1.05f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawTorusMesh();

	// ---------- INNER HEADBAND CUSHION ----------
	SetShaderTexture("carbon");
	SetShaderMaterial("carbon");
	SetTextureUVScale(1.0f, 1.0f);
	scaleXYZ = glm::vec3(1.35f, 1.35f, 0.10f);
	positionXYZ = glm::vec3(0.0f, 1.00f, -0.05f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawTorusMesh();

	// ---------- LEFT RED SUPPORT ----------
	SetShaderColor(0.85f, 0.0f, 0.05f, 1.0f);
	SetShaderMaterial("leather");
	scaleXYZ = glm::vec3(0.08f, 1.10f, 0.08f);
	positionXYZ = glm::vec3(-1.15f, 0.75f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, -25.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// ---------- RIGHT RED SUPPORT ----------
	SetShaderColor(0.85f, 0.0f, 0.05f, 1.0f);
	SetShaderMaterial("leather");
	scaleXYZ = glm::vec3(0.08f, 1.10f, 0.08f);
	positionXYZ = glm::vec3(1.15f, 0.75f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 25.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// ---------- LEFT HINGE JOINT ----------
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);
	SetShaderMaterial("leather");
	scaleXYZ = glm::vec3(0.22f, 0.22f, 0.22f);
	positionXYZ = glm::vec3(-1.25f, 0.55f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawSphereMesh();

	// ---------- RIGHT HINGE JOINT ----------
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);
	SetShaderMaterial("leather");
	scaleXYZ = glm::vec3(0.22f, 0.22f, 0.22f);
	positionXYZ = glm::vec3(1.25f, 0.55f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawSphereMesh();

	// ---------- LEFT SMALL LOGO PLATE ----------
	SetShaderColor(0.20f, 0.20f, 0.20f, 1.0f);
	scaleXYZ = glm::vec3(0.35f, 0.05f, 0.35f);
	positionXYZ = glm::vec3(-1.25f, -0.03f, -0.35f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	// ---------- RIGHT SMALL LOGO PLATE ----------
	SetShaderColor(0.20f, 0.20f, 0.20f, 1.0f);
	scaleXYZ = glm::vec3(0.35f, 0.05f, 0.35f);
	positionXYZ = glm::vec3(1.25f, -0.03f, -0.35f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	// ---------- MICROPHONE ARM ----------
	SetShaderColor(0.85f, 0.0f, 0.05f, 1.0f);
	scaleXYZ = glm::vec3(0.05f, 0.90f, 0.05f);
	positionXYZ = glm::vec3(-1.75f, -0.35f, 0.15f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 55.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// ---------- MICROPHONE TIP ----------
	SetShaderColor(0.02f, 0.02f, 0.02f, 1.0f);
	scaleXYZ = glm::vec3(0.18f, 0.18f, 0.18f);
	positionXYZ = glm::vec3(-2.10f, -0.75f, 0.15f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawSphereMesh();
}