#version 330 core

out vec4 fragmentColor;

in vec3 fragmentPosition;
in vec3 fragmentVertexNormal;
in vec2 fragmentTextureCoordinate;

struct Material {
    vec3 diffuseColor;
    vec3 specularColor;
    float shininess;
};

struct DirectionalLight {
    vec3 direction;
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    bool bActive;
};

struct PointLight {
    vec3 position;
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    bool bActive;
};

struct SpotLight {
    vec3 position;
    vec3 direction;
    float cutOff;
    float outerCutOff;
    float constant;
    float linear;
    float quadratic;
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    bool bActive;
};

#define TOTAL_POINT_LIGHTS 5

uniform bool bUseTexture = false;
uniform bool bUseLighting = false;
uniform vec4 objectColor = vec4(1.0f);
uniform vec3 viewPosition;

uniform DirectionalLight directionalLight;
uniform PointLight pointLights[TOTAL_POINT_LIGHTS];
uniform SpotLight spotLight;
uniform Material material;

uniform sampler2D objectTexture;
uniform vec2 UVscale = vec2(1.0f, 1.0f);

vec3 CalcDirectionalLight(DirectionalLight light, vec3 normal, vec3 viewDir);
vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir);
vec3 CalcSpotLight(SpotLight light, vec3 normal, vec3 fragPos, vec3 viewDir);

void main()
{
    vec4 baseColor = objectColor;

    if (bUseTexture == true)
    {
        baseColor = texture(objectTexture, fragmentTextureCoordinate * UVscale);
    }

    if (bUseLighting == true)
    {
        vec3 phongResult = vec3(0.0f);
        vec3 norm = normalize(fragmentVertexNormal);
        vec3 viewDir = normalize(viewPosition - fragmentPosition);

        if (directionalLight.bActive == true)
        {
            phongResult += CalcDirectionalLight(directionalLight, norm, viewDir);
        }

        for (int i = 0; i < TOTAL_POINT_LIGHTS; i++)
        {
            if (pointLights[i].bActive == true)
            {
                phongResult += CalcPointLight(pointLights[i], norm, fragmentPosition, viewDir);
            }
        }

        if (spotLight.bActive == true)
        {
            phongResult += CalcSpotLight(spotLight, norm, fragmentPosition, viewDir);
        }

        fragmentColor = vec4(phongResult, baseColor.a);
    }
    else
    {
        fragmentColor = baseColor;
    }
}

vec3 CalcDirectionalLight(DirectionalLight light, vec3 normal, vec3 viewDir)
{
    vec3 baseColor = vec3(objectColor);

    if (bUseTexture == true)
    {
        baseColor = vec3(texture(objectTexture, fragmentTextureCoordinate * UVscale));
    }

    vec3 lightDirection = normalize(-light.direction);

    float diff = max(dot(normal, lightDirection), 0.0);

    vec3 reflectDir = reflect(-lightDirection, normal);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);

    vec3 ambient = light.ambient * baseColor;
    vec3 diffuse = light.diffuse * diff * material.diffuseColor * baseColor;
    vec3 specular = light.specular * spec * material.specularColor;

    return ambient + diffuse + specular;
}

vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir)
{
    vec3 baseColor = vec3(objectColor);

    if (bUseTexture == true)
    {
        baseColor = vec3(texture(objectTexture, fragmentTextureCoordinate * UVscale));
    }

    vec3 lightDir = normalize(light.position - fragPos);

    float diff = max(dot(normal, lightDir), 0.0);

    vec3 reflectDir = reflect(-lightDir, normal);
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);

    vec3 ambient = light.ambient * baseColor;
    vec3 diffuse = light.diffuse * diff * material.diffuseColor * baseColor;
    vec3 specular = light.specular * specularComponent * material.specularColor;

    return ambient + diffuse + specular;
}

vec3 CalcSpotLight(SpotLight light, vec3 normal, vec3 fragPos, vec3 viewDir)
{
    vec3 baseColor = vec3(objectColor);

    if (bUseTexture == true)
    {
        baseColor = vec3(texture(objectTexture, fragmentTextureCoordinate * UVscale));
    }

    vec3 lightDir = normalize(light.position - fragPos);

    float diff = max(dot(normal, lightDir), 0.0);

    vec3 reflectDir = reflect(-lightDir, normal);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);

    float distance = length(light.position - fragPos);
    float attenuation = 1.0 / 
        (light.constant + light.linear * distance + light.quadratic * (distance * distance));

    vec3 ambient = light.ambient * baseColor;
    vec3 diffuse = light.diffuse * diff * material.diffuseColor * baseColor;
    vec3 specular = light.specular * spec * material.specularColor;

    ambient *= attenuation;
    diffuse *= attenuation;
    specular *= attenuation;

    return ambient + diffuse + specular;
}